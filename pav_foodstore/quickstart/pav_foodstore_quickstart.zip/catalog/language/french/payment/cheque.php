<?php
// Text
$_['text_title']		= 'Instructions Ch&egrave;que - Mandat postal';
$_['text_instruction']	= 'Ch&egrave;que - Mandat postal';
$_['text_payable']		= '&Agrave; :';
$_['text_address']		= '&Agrave; adresser &agrave; :';
$_['text_payment']		= 'Votre commande ne sera pas livr&eacute;e qu&#8217;&agrave; r&eacute;ception du paiement.';
?>