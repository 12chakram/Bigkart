<?php
// Text
$_['text_title']		= 'Virement bancaire';
$_['text_instruction']	= 'Instructions sur le virement bancaire';
$_['text_description']	= 'Veuillez effectuer un virement de la somme en totalit&eacute; sur le compte bancaire suivant.';
$_['text_payment']		= 'Votre commande ne sera livr&eacute;e qu&#8217;&agrave; r&eacute;ception du paiement.';
?>