<?php
// Entry
$_['entry_postcode']	= 'Code postal :';
$_['entry_country']		= 'Pays :';
$_['entry_zone']		= 'D&eacute;partement :';
?>