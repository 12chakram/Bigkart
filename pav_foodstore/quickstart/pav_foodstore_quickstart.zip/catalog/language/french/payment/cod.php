<?php
// Text
$_['text_title']	= 'Paiement &agrave; la livraison';
?>