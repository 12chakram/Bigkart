<?php
// Text
$_['text_title']	= 'Carte de cr&eacute;dit (Mal&#8217;s e-commerce)';
?>