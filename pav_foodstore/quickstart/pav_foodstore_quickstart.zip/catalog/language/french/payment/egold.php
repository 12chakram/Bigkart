<?php
// Text
$_['text_title']	= 'Carte de cr&eacute;dit (eGold)';
?>