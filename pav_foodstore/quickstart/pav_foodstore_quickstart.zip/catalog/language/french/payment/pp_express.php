<?php
// Text
$_['text_title']	= 'PayPal Express (y compris cartes de cr&eacute;dit et cartes de d&eacute;bit)';
?>