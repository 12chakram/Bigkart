<?php
// Text
$_['text_title']		= 'Carte de cr&eacute;dit (SagePay)';
$_['text_description']	= 'Produits sur %s commande N&deg; : %s';
?>