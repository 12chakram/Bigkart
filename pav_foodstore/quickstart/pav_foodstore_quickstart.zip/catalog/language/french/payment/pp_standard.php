<?php
// Text
$_['text_title']	= 'PayPal';
$_['text_reason']	= 'Raison';
$_['text_testmode']	= 'Attention, la passerelle de paiement est en &#8217;Mode Sandbox&#8217;. Votre compte ne sera pas d&eacute;bit&eacute;.';
$_['text_total']	= 'Livraisons, manutentions, remises et taxes';
?>