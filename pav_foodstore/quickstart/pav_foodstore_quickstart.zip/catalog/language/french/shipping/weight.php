<?php
// Text
$_['text_title']	= 'Livraison bas&eacute;e sur le poids';
$_['text_weight']	= 'Poids :'; 
?>