<?php
// Text
$_['text_title']				= 'Royal Mail';
$_['text_weight']				= 'Poids :';
$_['text_insurance']			= 'Assur&eacute; &agrave; hauteur de :';
$_['text_1st_class_standard']   = 'Courrier standard de premi&egrave;re classe';
$_['text_1st_class_recorded']   = 'Courrier enregistr&eacute; de premi&egrave;re classe';
$_['text_2nd_class_standard']   = 'Courrier standard de seconde classe';
$_['text_2nd_class_recorded']   = 'Courrier enregistr&eacute; de seconde classe';
$_['text_special_delivery_500']	= 'Livraison sp&eacute;ciale Jour suivant (� 500)';
$_['text_special_delivery_1000']= 'Livraison sp&eacute;ciale Jour suivant (� 1000)';
$_['text_special_delivery_2500']= 'Livraison sp&eacute;ciale Jour suivant (� 2500)';
$_['text_standard_parcels']     = 'Colis standard';
$_['text_airmail']              = 'Poste a&eacute;rienne';
$_['text_international_signed'] = 'International avec signature';
$_['text_airsure']              = 'Airsure';
$_['text_surface']              = 'Surface';
?>