<?php
// Text
$_['text_title']		= 'Retrait au Magasin';
$_['text_description']	= 'Retrait au Magasin';
?>