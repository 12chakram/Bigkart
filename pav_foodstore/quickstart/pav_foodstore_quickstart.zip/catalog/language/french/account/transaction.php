<?php
// Heading 
$_['heading_title']			= 'Vos transactions';

// Column
$_['column_date_added']		= 'Date d&#8217;ajout';
$_['column_description']	= 'Description';
$_['column_amount']			= 'Montant (%s)';

// Text
$_['text_account']			= 'Compte';
$_['text_transaction']		= 'Vos transactions';
$_['text_total']			= 'Votre solde actuel est de :';
$_['text_empty']			= 'Vous n&#8217;avez aucune transaction';
?>