<?php
// Heading 
$_['heading_title']		= 'Vos t&eacute;l&eacute;chargements';

// Text
$_['text_account']		= 'Compte';
$_['text_downloads']	= 'T&eacute;l&eacute;chargements';
$_['text_order']		= 'R&eacute;f. commande :';
$_['text_date_added']	= 'Date d&#8217;ajout :';
$_['text_name']			= 'Nom :';
$_['text_remaining']	= 'Restant :';
$_['text_size']			= 'Taille :';
$_['text_download']		= 'T&eacute;l&eacute;chargez';
$_['text_empty']		= 'Vous n&#8217;avez effectu&eacute; aucune commande t&eacute;l&eacute;chargeable ! ';
?>