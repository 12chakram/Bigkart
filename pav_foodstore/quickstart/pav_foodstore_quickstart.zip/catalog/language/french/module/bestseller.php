<?php
// Heading 
$_['heading_title']		= 'Meilleures ventes';

// Text
$_['text_reviews']		= 'Bas&eacute; sur %s avis.'; 
?>