<?php
// Heading 
$_['heading_title']		= 'Compte';

// Text
$_['text_register']		= 'Enregistrement';
$_['text_login']		= 'Connexion';
$_['text_logout']		= 'Se d&eacute;connecter';
$_['text_forgotten']	= 'Mot de passe oubli&eacute;';
$_['text_account']		= 'Mon compte';
$_['text_edit']			= '&Eacute;dition du compte';
$_['text_password']		= 'Mot de passe';
$_['text_wishlist']		= 'Liste de souhaits';
$_['text_order']		= 'Historique de commandes';
$_['text_download']		= 'T&eacute;l&eacute;chargements';
$_['text_return']		= 'Retours produits';
$_['text_transaction']	= 'Transactions';
$_['text_newsletter']	= 'Lettre d&#8217;information';
?>
