<?php
// Heading 
$_['heading_title']		= 'Informations';

// Text
$_['text_contact']		= 'Nous contacter';
$_['text_sitemap']		= 'Plan du site';
?>