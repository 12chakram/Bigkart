<?php
// Heading 
$_['heading_title']		= 'Dialogue en direct';
?>