<?php
$_['heading_title']	= 'Bienvenue sur %s';
?>