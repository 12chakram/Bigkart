<?php
// Heading
$_['heading_title']	= 'Cat&eacute;gories';
?>