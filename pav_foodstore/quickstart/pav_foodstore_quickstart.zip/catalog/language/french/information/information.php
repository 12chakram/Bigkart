<?php
// Text
$_['text_error']	= 'Page d&#8217;information introuvable !';
?>