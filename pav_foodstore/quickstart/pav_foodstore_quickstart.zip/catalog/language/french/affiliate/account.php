<?php
// Heading 
$_['heading_title']			= 'Mon compte affili&eacute;';

// Text
$_['text_account']			= 'Compte';
$_['text_my_account']		= 'Mon compte affili&eacute;';
$_['text_my_tracking']		= 'Mon suivi d&#8217;information';
$_['text_my_transactions']	= 'Mes transactions';
$_['text_edit']				= 'Editer le compte information';
$_['text_password']			= 'Changer mon mot de passe';
$_['text_payment']			= 'Changer mes pr&eacute;f&eacute;rences de paiement';
$_['text_tracking']			= 'Personnaliser le suivi du code affili&eacute;';
$_['text_transaction']		= 'Voir l&#8217;historique des transactions';
?>