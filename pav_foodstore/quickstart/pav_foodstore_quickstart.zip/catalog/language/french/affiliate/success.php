<?php
// Heading
$_['heading_title']	= 'Votre compte affili&eacute; a bien &eacute;t&eacute; cr&eacute;&eacute; !';

// Text 
$_['text_approval']	= '<p>Nous vous remercions de votre inscription pour un partenariat avec %s !</p><p>Vous serez avis&eacute; par courriel d&egrave;s que votre compte sera activ&eacute;.</p><p>Si vous avez des questions concernant le fonctionnement de ce syst&egrave;me d&#8217;affiliation, n&#8217:h&eacute;sitez pas &agrave; <a href="%s">nous contacter</a>.</p>';
$_['text_account']	= 'Compte';
$_['text_success']	= 'F&eacute;licitations';
?>