<?php
// Text
$_['text_subject']	= '%s - Programme d&#8217;affiliation';
$_['text_welcome']	= 'Nous vous remercions de votre enregistrement au programme d&#8217;affiliation et vous souhaitons la bienvenue sur %s !';
$_['text_approval']	= 'Votre compte a &eacute;t&eacute; approuv&eacute;, vous pouvez d&eacute;sormais vous connecter en utilisant votre adresse courriel et mot de passe &agrave; l&#8217;adresse suivante :';
$_['text_services']	= 'Apr&egrave;s votre connexion, vous serez en mesure de g&eacute;n&eacute;rer des codes de suivi, de suivre le paiement de vos commissions et de modifier vos informations de compte.';
$_['text_thanks']	= 'Remerciements,';
?>