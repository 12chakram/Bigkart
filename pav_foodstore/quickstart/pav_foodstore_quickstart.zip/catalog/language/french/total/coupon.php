<?php
// Heading 
$_['heading_title']	= 'Appliquer le code de remise';

// Text
$_['text_coupon']	= 'Coupon(%s) :';
$_['text_success']	= 'F&eacute;licitations, votre bon de r&eacute;duction a &eacute;t&eacute; appliqu&eacute; avec succ&egrave;s !';

// Entry
$_['entry_coupon']	= 'Entrer le bon de r&eacute;duction ici :';

// Error
$_['error_coupon']	= 'Attention, votre bon de r&eacute;duction est soit invalide, soit expir&eacute; ou a atteint sa date limite d&#8217;utilisation !';
?>