<?php
$_['text_credit']	= 'Cr&eacute;dit boutique :';
$_['text_order_id']	= 'Identifiant commande : #%s';
?>