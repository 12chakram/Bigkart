<?php
// Heading 
$_['heading_title']	= 'Utilisation du bon de r&eacute;duction';

// Text
$_['text_voucher']	= 'Bon de r&eacute;duction (%s):';
$_['text_success']	= 'F&eacute;licitations, la r&eacute;duction pour vos bons a &eacute;t&eacute; appliqu&eacute;e avec succ&egrave;s !';

// Entry
$_['entry_voucher']	= 'Entrer le code pour votre bon de r&eacute;duction ici :';

// Error
$_['error_voucher']	= 'Erreur, le bon de r&eacute;duction est invalide ou le solde a &eacute;t&eacute; utilis&eacute; !';
?>