<?php
$_['text_handling'] = 'Frais de manutention :';
?>