<?php
// Text
$_['text_home']		= 'Accueil';
$_['text_wishlist']	= 'Liste de souhaits (%s)';
$_['text_cart']		= 'Panier';
$_['text_items']	= '%s article(s) - %s';
$_['text_search']	= 'Recherche';
$_['text_welcome']	= 'Vous pouvez <a href="%s">vous connecter</a> ou <a href="%s">cr&eacute;er un compte</a>.';
$_['text_logged']	= 'Vous &ecirc;tes connect&eacute; sur <a href="%s">%s</a> <b>(</b> <a href="%s">Se d&eacute;connecter</a> <b>)</b>';
$_['text_account']	= 'Compte';
$_['text_checkout']	= 'Commander';
$_['text_language']	= 'Langue';
$_['text_currency']	= 'Devise';
?>