<?php
$_['text_sub_total'] = 'جمع جز';
?>