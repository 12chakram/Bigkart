<?php
$_['text_credit']   = 'اعتبار فروشگاه';
$_['text_order_id'] = 'کد سفارش: #%s';
?>