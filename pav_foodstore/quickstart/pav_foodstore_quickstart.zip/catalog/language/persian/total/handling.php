<?php
$_['text_handling'] = 'هزينه حمل';
?>