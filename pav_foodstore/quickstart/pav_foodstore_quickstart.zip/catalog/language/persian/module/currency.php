<?php
// Text
$_['text_currency'] = 'واحد پول';
?>