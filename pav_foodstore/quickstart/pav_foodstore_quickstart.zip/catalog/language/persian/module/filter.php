<?php
// Heading
$_['heading_title'] = 'جستجوی دقیق تر';
?>