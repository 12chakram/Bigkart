<?php
// Heading 
$_['heading_title']  = 'ویژه ها';

// Text
$_['text_reviews']  = 'بر اساس %s نظر.'; 
?>