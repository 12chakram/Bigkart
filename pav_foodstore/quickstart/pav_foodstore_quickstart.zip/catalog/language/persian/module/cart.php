<?php
// Heading 
$_['heading_title'] = 'سبد خرید';

// Text
$_['text_items']    = '%s کالا(ها) - %s';
$_['text_empty']    = 'سبد خرید شما خالی است!';
$_['text_cart']     = 'مشاهده سبد';
$_['text_checkout'] = 'تسویه حساب';
?>