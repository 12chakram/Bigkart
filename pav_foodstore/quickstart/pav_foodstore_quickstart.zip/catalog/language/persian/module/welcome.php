<?php
$_['heading_title'] = 'به %s خوش آمدید';
?>