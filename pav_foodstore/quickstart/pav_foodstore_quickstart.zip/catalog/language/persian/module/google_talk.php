<?php
// Heading 
$_['heading_title']  = 'گفتگوی زنده';
?>