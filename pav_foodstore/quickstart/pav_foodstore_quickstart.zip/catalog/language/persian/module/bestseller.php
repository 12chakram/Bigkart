<?php
// Heading 
$_['heading_title'] = 'پرفروش ترین ها';

// Text
$_['text_reviews']  = 'بر اساس %s نظر.'; 
?>