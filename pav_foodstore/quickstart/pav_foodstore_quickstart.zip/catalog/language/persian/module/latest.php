<?php
// Heading 
$_['heading_title'] = 'جديدترين کالاها';

// Text
$_['text_reviews']  = 'بر اساس %s نظر.'; 
?>