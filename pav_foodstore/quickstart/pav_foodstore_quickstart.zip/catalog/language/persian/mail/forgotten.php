<?php
// Text
$_['text_subject']  = '%s - رمز عبور جدید';
$_['text_greeting'] = 'رمز عبور جدید توسط %s درخواست شده است.';
$_['text_password'] = 'رمز عبور جدید شما:';
?>