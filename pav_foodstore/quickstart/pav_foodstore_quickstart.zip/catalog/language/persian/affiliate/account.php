<?php
// Heading 
$_['heading_title']        = 'حساب بازاریابی من';

// Text
$_['text_account']         = 'حساب';
$_['text_my_account']      = 'حساب بازاریابی من';
$_['text_my_tracking']     = 'پیگیری اطلاعات من';
$_['text_my_transactions'] = 'تراکنش های من';
$_['text_edit']            = 'اطلاعات حساب کاربری خود را ویرایش کنید';
$_['text_password']        = 'تغییر رمز عبور خود';
$_['text_payment']         = 'تغییر اطلاعات حساب بانکی';
$_['text_tracking']        = 'شماره رهگیری اختصاصی';
$_['text_transaction']     = 'نمایش تاریخ تراکنش';
?>