<?php
// Heading 
$_['heading_title'] = 'خارج شدن از حساب';

// Text
$_['text_message']  = '<p>شما از حساب بازاریابی خود خارج شده اید.</p>';
$_['text_account']  = 'حساب';
$_['text_logout']   = 'خروج';
?>