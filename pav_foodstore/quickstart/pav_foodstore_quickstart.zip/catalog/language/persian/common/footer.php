<?php
// Text
$_['text_information']  = 'اطلاعات';
$_['text_service']      = 'خدمات مشتریان';
$_['text_extra']        = 'موارد اضافی';
$_['text_contact']      = 'تماس با ما';
$_['text_return']       = 'استرداد کالا';
$_['text_sitemap']      = 'نقشه سایت';
$_['text_manufacturer'] = 'تولید کنندگان';
$_['text_voucher']      = 'کارت هدیه';
$_['text_affiliate']    = 'بازاریابی';
$_['text_special']      = 'کالاهای ویژه';
$_['text_account']      = 'حساب کاربری من';
$_['text_order']        = 'تاریخچه سفارشات';
$_['text_wishlist']     = 'لیست دلخواه';
$_['text_newsletter']   = 'خبرنامه';
$_['text_powered']      = 'پشتیبان: <a href="http://www.opencart.ir">اپن کارت</a><a href="http://www.opencart.com/index.php?route=partner/partner#country101"> (OpenCart) </a><a href="http://www.opencart.ir">فارسی</a><br /> %s &copy; %s';
//کاربر گرامی حذف کپی رایت نماینده رسمی اپن کارت فارسی در ایران، به معنای حذف واقعی پشتیبانی شما خواهد بود و در صورت گزارش سایت شما به سایت رسمی اپن کارت، اکانت شما در سایت اصلی نیز مسدود می شود. لذا به هیچ وجه اقدام به حذف کپی رایت نکنید. با تشکر

?>