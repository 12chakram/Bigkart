<?php
// Text
$_['text_title'] = 'پرداخت رايگان';
?>