<?php
// Text
$_['text_title']  = 'حمل بر اساس وزن';
$_['text_weight'] = 'وزن:'; 
?>