<?php
// Text
$_['text_title']       = 'ارسال 48 ساعته';
$_['text_description'] = 'ارسال در 48 ساعت';
$_['text_weight']      = 'وزن:'; 
$_['text_insurance']   = 'بيمه تا سقف:';   
$_['text_time']        = 'تخمين زمان: در عرض 48 ساعت'; 
?>