<?php
// Text
$_['text_title']       = 'ارسال رایگان';
$_['text_description'] = 'ارسال رایگان';
?>