<?php
// Heading
$_['heading_title']    = 'نقشه سایت';
 
// Text
$_['text_special']     = 'پیشنهادات ویژه';
$_['text_account']     = 'حساب کاربری من';
$_['text_edit']        = 'اطلاعات حساب';
$_['text_password']    = 'رمز عبور';
$_['text_address']     = 'دفترچه آدرس';
$_['text_history']     = 'تاریخچه سفارشات';
$_['text_download']    = 'دانلودها';
$_['text_cart']        = 'سبد خرید';
$_['text_checkout']    = 'تسویه حساب';
$_['text_search']      = 'جستجو';
$_['text_information'] = 'اطلاعات';
$_['text_contact']     = 'تماس با ما';
?>
