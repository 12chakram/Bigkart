<?php
// Text
$_['text_error'] = 'صفحه اطلاعات یافت نشد!';
?>