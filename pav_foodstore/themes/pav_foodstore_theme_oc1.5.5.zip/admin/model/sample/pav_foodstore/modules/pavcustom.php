a:6:{i:1;a:8:{s:12:"module_title";a:3:{i:1;s:17:"Banner MassBottom";i:3;s:17:"Banner MassBottom";i:4;s:17:"Banner MassBottom";}s:11:"description";a:3:{i:1;s:1519:"&lt;div class=&quot;media-list row &quot;&gt;
&lt;div class=&quot;col-lg-4 col-md-4 col-sm-12&quot;&gt;
&lt;div class=&quot;media&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner4.png&quot; /&gt; &lt;/a&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading text-primary-theme&quot;&gt;Chicken&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 col-sm-12&quot;&gt;
&lt;div class=&quot;media&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner5.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading text-danger-theme&quot;&gt;Soda-Burger&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 col-sm-12&quot;&gt;
&lt;div class=&quot;media&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner6.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading&quot;&gt;Breakfast&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:3;s:1519:"&lt;div class=&quot;media-list row &quot;&gt;
&lt;div class=&quot;col-lg-4 col-md-4 col-sm-12&quot;&gt;
&lt;div class=&quot;media&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner4.png&quot; /&gt; &lt;/a&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading text-primary-theme&quot;&gt;Chicken&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 col-sm-12&quot;&gt;
&lt;div class=&quot;media&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner5.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading text-danger-theme&quot;&gt;Soda-Burger&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 col-sm-12&quot;&gt;
&lt;div class=&quot;media&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner6.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading&quot;&gt;Breakfast&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:4;s:1519:"&lt;div class=&quot;media-list row &quot;&gt;
&lt;div class=&quot;col-lg-4 col-md-4 col-sm-12&quot;&gt;
&lt;div class=&quot;media&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner4.png&quot; /&gt; &lt;/a&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading text-primary-theme&quot;&gt;Chicken&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 col-sm-12&quot;&gt;
&lt;div class=&quot;media&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner5.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading text-danger-theme&quot;&gt;Soda-Burger&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 col-sm-12&quot;&gt;
&lt;div class=&quot;media&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner6.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading&quot;&gt;Breakfast&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:5:"99999";s:8:"position";s:11:"mass_bottom";s:6:"status";s:1:"1";s:12:"module_class";s:20:"box-media media-dark";s:10:"sort_order";s:0:"";}i:2;a:8:{s:12:"module_title";a:3:{i:1;s:8:"About us";i:3;s:0:"";i:4;s:0:"";}s:11:"description";a:3:{i:1;s:1587:"&lt;div class=&quot;about-us&quot;&gt;
&lt;p&gt;&lt;img src=&quot;image/data/banner1.jpg&quot; /&gt;&lt;/p&gt;

&lt;p&gt;Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat sociosqu ad litora dolorem ipsum quia dolor sit amet, consectetur feugiat, velit mauris egestas quam, ut aliquam massa nisl quis neque.&lt;/p&gt;
&lt;/div&gt;

&lt;div class=&quot;social&quot;&gt;
&lt;ul&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox pinterest&quot; data-original-title=&quot;pinterest&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-pinterest&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox facebook&quot; data-original-title=&quot;facebook&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-facebook&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox google-plus&quot; data-original-title=&quot;google-plus&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-google-plus&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox twitter&quot; data-original-title=&quot;twitter&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-twitter&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:3;s:1587:"&lt;div class=&quot;about-us&quot;&gt;
&lt;p&gt;&lt;img src=&quot;image/data/banner1.jpg&quot; /&gt;&lt;/p&gt;

&lt;p&gt;Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat sociosqu ad litora dolorem ipsum quia dolor sit amet, consectetur feugiat, velit mauris egestas quam, ut aliquam massa nisl quis neque.&lt;/p&gt;
&lt;/div&gt;

&lt;div class=&quot;social&quot;&gt;
&lt;ul&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox pinterest&quot; data-original-title=&quot;pinterest&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-pinterest&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox facebook&quot; data-original-title=&quot;facebook&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-facebook&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox google-plus&quot; data-original-title=&quot;google-plus&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-google-plus&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox twitter&quot; data-original-title=&quot;twitter&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-twitter&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:4;s:1587:"&lt;div class=&quot;about-us&quot;&gt;
&lt;p&gt;&lt;img src=&quot;image/data/banner1.jpg&quot; /&gt;&lt;/p&gt;

&lt;p&gt;Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat sociosqu ad litora dolorem ipsum quia dolor sit amet, consectetur feugiat, velit mauris egestas quam, ut aliquam massa nisl quis neque.&lt;/p&gt;
&lt;/div&gt;

&lt;div class=&quot;social&quot;&gt;
&lt;ul&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox pinterest&quot; data-original-title=&quot;pinterest&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-pinterest&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox facebook&quot; data-original-title=&quot;facebook&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-facebook&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox google-plus&quot; data-original-title=&quot;google-plus&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-google-plus&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;iconbox twitter&quot; data-original-title=&quot;twitter&quot; data-placement=&quot;top&quot; data-toggle=&quot;tooltip&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;icon-twitter&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";i:1;}i:3;a:8:{s:12:"module_title";a:3:{i:1;s:18:"Banner Content Top";i:3;s:0:"";i:4;s:0:"";}s:11:"description";a:3:{i:1;s:315:"&lt;div class=&quot;row&quot;&gt;
&lt;div class=&quot;col-lg-6 col-md-6 col-sm-6 col-xs-12&quot;&gt;&lt;img src=&quot;image/data/banner1.jpg&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;col-lg-6 col-md-6 col-sm-6 col-xs-12&quot;&gt;&lt;img src=&quot;image/data/banner2.jpg&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;
";i:3;s:315:"&lt;div class=&quot;row&quot;&gt;
&lt;div class=&quot;col-lg-6 col-md-6 col-sm-6 col-xs-12&quot;&gt;&lt;img src=&quot;image/data/banner1.jpg&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;col-lg-6 col-md-6 col-sm-6 col-xs-12&quot;&gt;&lt;img src=&quot;image/data/banner2.jpg&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;
";i:4;s:315:"&lt;div class=&quot;row&quot;&gt;
&lt;div class=&quot;col-lg-6 col-md-6 col-sm-6 col-xs-12&quot;&gt;&lt;img src=&quot;image/data/banner1.jpg&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;col-lg-6 col-md-6 col-sm-6 col-xs-12&quot;&gt;&lt;img src=&quot;image/data/banner2.jpg&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:11:"content_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"2";}i:4;a:8:{s:12:"module_title";a:3:{i:1;s:10:"List Order";i:3;s:10:"List Order";i:4;s:10:"List Order";}s:11:"description";a:3:{i:1;s:1663:"&lt;ul class=&quot;media-list&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-menu.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Menu&lt;/h4&gt;

	&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-wines.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Wines&lt;/h4&gt;

	&lt;p&gt;Cras purus odio, vestibulum in tempus viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-team.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Meet the Team&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero itudin commodoturpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-find.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Where to find us&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";i:3;s:1663:"&lt;ul class=&quot;media-list&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-menu.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Menu&lt;/h4&gt;

	&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-wines.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Wines&lt;/h4&gt;

	&lt;p&gt;Cras purus odio, vestibulum in tempus viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-team.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Meet the Team&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero itudin commodoturpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-find.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Where to find us&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";i:4;s:1663:"&lt;ul class=&quot;media-list&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-menu.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Menu&lt;/h4&gt;

	&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-wines.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Wines&lt;/h4&gt;

	&lt;p&gt;Cras purus odio, vestibulum in tempus viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-team.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Meet the Team&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero itudin commodoturpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-find.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Where to find us&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:11:"column_left";s:6:"status";s:1:"1";s:12:"module_class";s:9:"nopadding";s:10:"sort_order";s:1:"2";}i:5;a:8:{s:12:"module_title";a:3:{i:1;s:10:"List Order";i:3;s:10:"List Order";i:4;s:10:"List Order";}s:11:"description";a:3:{i:1;s:1663:"&lt;ul class=&quot;media-list&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-menu.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Menu&lt;/h4&gt;

	&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-wines.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Wines&lt;/h4&gt;

	&lt;p&gt;Cras purus odio, vestibulum in tempus viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-team.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Meet the Team&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero itudin commodoturpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-find.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Where to find us&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";i:3;s:1663:"&lt;ul class=&quot;media-list&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-menu.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Menu&lt;/h4&gt;

	&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-wines.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Wines&lt;/h4&gt;

	&lt;p&gt;Cras purus odio, vestibulum in tempus viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-team.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Meet the Team&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero itudin commodoturpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-find.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Where to find us&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";i:4;s:1663:"&lt;ul class=&quot;media-list&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-menu.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Menu&lt;/h4&gt;

	&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-wines.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Wines&lt;/h4&gt;

	&lt;p&gt;Cras purus odio, vestibulum in tempus viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-team.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Meet the Team&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero itudin commodoturpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-find.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Where to find us&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"2";s:8:"position";s:11:"column_left";s:6:"status";s:1:"1";s:12:"module_class";s:9:"nopadding";s:10:"sort_order";s:1:"2";}i:6;a:8:{s:12:"module_title";a:3:{i:1;s:10:"List Order";i:3;s:10:"List Order";i:4;s:10:"List Order";}s:11:"description";a:3:{i:1;s:1663:"&lt;ul class=&quot;media-list&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-menu.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Menu&lt;/h4&gt;

	&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-wines.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Wines&lt;/h4&gt;

	&lt;p&gt;Cras purus odio, vestibulum in tempus viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-team.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Meet the Team&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero itudin commodoturpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-find.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Where to find us&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";i:3;s:1663:"&lt;ul class=&quot;media-list&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-menu.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Menu&lt;/h4&gt;

	&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-wines.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Wines&lt;/h4&gt;

	&lt;p&gt;Cras purus odio, vestibulum in tempus viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-team.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Meet the Team&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero itudin commodoturpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-find.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Where to find us&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";i:4;s:1663:"&lt;ul class=&quot;media-list&quot;&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-menu.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Menu&lt;/h4&gt;

	&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-wines.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Our Wines&lt;/h4&gt;

	&lt;p&gt;Cras purus odio, vestibulum in tempus viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-team.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Meet the Team&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero itudin commodoturpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
	&lt;li class=&quot;media&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-find.png&quot; /&gt; &lt;/a&gt;
	&lt;div class=&quot;media-body&quot;&gt;
	&lt;h4 class=&quot;media-heading&quot;&gt;Where to find us&lt;/h4&gt;

	&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
	&lt;/div&gt;
	&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"3";s:8:"position";s:11:"column_left";s:6:"status";s:1:"1";s:12:"module_class";s:9:"nopadding";s:10:"sort_order";s:1:"2";}}