<?php
// Heading 
$_['heading_title'] = 'Latest';

// Text
$_['text_latest']  = 'Latest'; 
$_['text_mostviewed']  = 'Most Viewed'; 
$_['text_featured']  = 'Featured'; 
$_['text_bestseller']  = 'Best Seller'; 
$_['text_special']  = 'Special';
?>